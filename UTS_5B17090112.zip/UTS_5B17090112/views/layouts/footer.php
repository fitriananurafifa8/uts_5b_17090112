<div class="jumbotron jumbotron-fluid p-3 p-md-5 text-white bg-dark">
    <div class="container">
        <div class="col-md-12 px-0 text-center">
            <p class="lead py-3">
                SMK BAKTI PRAJA DUKUHARU <br>
                Jalan Raya Barat Dukuhwaru <br>
                telp. (0283) 12371821 - fax. (0283) 82838231 Kode Pos. 52451 <br>
                Kabupaten Tegal
            </p>
        </div>
    </div>
</div>